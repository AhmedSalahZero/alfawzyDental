<?php $__env->startSection('title'); ?>

    Home
<?php $__env->stopSection(); ?>

<?php $__env->startPush('content'); ?>

    <?php echo $__env->make('front.home.parts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('front.home.parts.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.home.parts.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.home.parts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('front.home.parts.dental', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.home.parts.review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.home.parts.patient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.home.parts.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('front.home.parts.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
    <style>
        .testimonial-swiper {
            max-width: 100%;
        }
    </style>
    <script>
        window.addEventListener("load", function () {
            new Swiper(".testimonial-swiper", {
                loop: false,
                slidesPerView: "3",

                breakpoints: {
                    // when window width is >= 320px
                    320: {
                        slidesPerView: 1
                        , spaceBetween: 20
                    }
                    , 640: {
                        slidesPerView: 2
                        , spaceBetween: 20
                    },
                    // when window width is >= 480px

                    // when window width is >= 640px
                   // 1280: {
                   //     slidesPerView: 3
                   //     , spaceBetween: '40'
                   // }
                },
                spaceBetween: 30,
                speed: 6000,

                autoplay: {
                    delay: 0,
                    disableOnInteraction: false
                },

                // Navigation arrows

            });
            new Swiper(".testimonial-swiper2", {
                loop: false,

                grabCursor: true,
                slidesPerView: "3",
                breakpoints: {
                    // when window width is >= 320px
                    320: {
                        slidesPerView: 1
                        , spaceBetween: 20
                    }
                    , 640: {
                        slidesPerView: 2
                        , spaceBetween: 20
                    },
                    // when window width is >= 480px

                    // when window width is >= 640px
                   // 1280: {
                   //     slidesPerView: 3
                   //     , spaceBetween: '40'
                   // }
                },
                spaceBetween: 30,
                speed: 6000,

                autoplay: {
                    delay: 0,
                    disableOnInteraction: false
                },

                // Navigation arrows

            });
        });


    </script>

    <?php echo $__env->make('front.contact.contactJs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/home/home.blade.php ENDPATH**/ ?>