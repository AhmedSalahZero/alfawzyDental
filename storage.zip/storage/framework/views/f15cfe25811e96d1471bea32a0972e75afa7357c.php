  <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'enabled'=>true 
  ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'enabled'=>true 
  ]); ?>
<?php foreach (array_filter(([
	'enabled'=>true 
  ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
  <div class="
  <?php if($enabled): ?>
  doctors-card
  <?php endif; ?> 
  
   !px-5 shadow-lg  transition-all  duration-500   group/doctor-card preserve-3d  relative element-internal-padding rounded-[32px]">
                    <div class="card__front backface-hidden  text-center">
                        <?php echo e($front__face); ?>

                    </div>
                    <div class="card__back rotate-y-180 backface-hidden absolute top-0 left-0 right-0 bottom-0 flex flex-center element-internal-padding ">
                        <?php echo e($back__face); ?>

                    </div>
                </div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/cards/flip-card.blade.php ENDPATH**/ ?>