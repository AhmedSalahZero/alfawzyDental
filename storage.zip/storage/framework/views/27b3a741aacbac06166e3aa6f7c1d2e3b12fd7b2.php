<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'iconName'=>$iconName,
	'iconClass'=>$iconClass,
	'iconLink'=>$iconLink,
	'iconSize'=>$iconSize ?? 'icon-size'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'iconName'=>$iconName,
	'iconClass'=>$iconClass,
	'iconLink'=>$iconLink,
	'iconSize'=>$iconSize ?? 'icon-size'
]); ?>
<?php foreach (array_filter(([
	'iconName'=>$iconName,
	'iconClass'=>$iconClass,
	'iconLink'=>$iconLink,
	'iconSize'=>$iconSize ?? 'icon-size'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="" title="<?php echo e($iconName); ?>">
    <a target="_blank" class="bg-white hover:bg-[#B6B3B1] group/a p-2 rounded-full shadow-sm w-10 h-10 flex-center transition-all duration-300" href="<?php echo e($iconLink); ?>">
        <i title="<?php echo e($iconName); ?>" class="<?php echo e($iconClass); ?> <?php echo e($iconSize); ?> group-hover/a:text-white   transition-all duration-500 text-[#B6B3B1]">
        </i>
    </a>
</li>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/links/social-links.blade.php ENDPATH**/ ?>