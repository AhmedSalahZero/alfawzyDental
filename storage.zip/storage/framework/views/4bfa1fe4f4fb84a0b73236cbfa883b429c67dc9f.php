<div class="loader-ajax" style="display: none  ; ">
    <div class="lds-grid" >
        <div></div><div></div><div></div><div></div><div></div><div></div>
        <div></div><div></div><div>
        </div>
    </div>
</div>
<div class="lds-hourglass"></div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/layouts/loader/loader.blade.php ENDPATH**/ ?>