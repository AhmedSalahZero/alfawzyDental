
<div class="blog text-center md:text-left px-5 py-10 rounded-[32px] shadow-sm ">
    <a href="<?php echo e(route('web_blog.index',$id)); ?>" class="blog__img inline-block relative  max-w-[368px] mb-4">
        <img src="<?php echo e($img); ?>" class="max-w-full  rounded-2xl">
        <div class="blog__date absolute top-[10px] left-[10px] text-lg font-medium flex-center w-16 h-16 rounded-2xl bg-white text-black px-4 py-2">
            <span><?php echo e($date); ?></span>
        </div>
    </a>
    <div class="blog__title text-main text-xs font-bold mb-3">
        <?php echo e($title); ?>

    </div>
    <a href="<?php echo e(route('web_blog.index',$id)); ?>" class="blog__subtitle inline-block text-black font-semibold text-lg mb-3">
        <?php echo e($subtitle); ?>

    </a>
    <div class="blog__description text-[#918F8F] text-sm tracking-tight">
        <?php echo e($description); ?>

    </div>
</div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/blogs/blog.blade.php ENDPATH**/ ?>