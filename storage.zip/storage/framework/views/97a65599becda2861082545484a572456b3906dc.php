<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'reviews'=>$reviews??[]
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'reviews'=>$reviews??[]
]); ?>
<?php foreach (array_filter(([
'reviews'=>$reviews??[]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="testimonial py-10 px-5 shadow-lg rounded-2xl space-y-5 swiper-slide w-full md:w-[440px] mb-5 !h-max" >
        <div class="testimonial__upper flex items-center ">
            <div class="testimonal__image  mr-3 inline-block rounded-full">
                <img src="<?php echo e(get_file($review->image)); ?>" alt="" class="rounded-full border-[3px] border-[#EDE7E7] shadow-sm w-14 h-14 object-cover">
            </div>
            <div class="testimonial__info">
                <h3 class="normal__title capitalize text-sm"><?php echo e($review->name); ?> </h3>
                <div class="starts">
                    <?php for($star = 0 ; $star<$review->rate ; $star++): ?>
                        <i class="fa-solid fa-star text-main text-sm "></i>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="ml-auto float-right self-start">
                <i class="fa-solid fa-quote-right text-aquamarine text-2xl "></i>
            </div>
        </div>
        <p class="text-[#6B7385]">
            <?php echo e($review->text); ?>

        </p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if (! $__env->hasRenderedOnce('35865a87-d8f1-4492-8903-cfe8f462baca')): $__env->markAsRenderedOnce('35865a87-d8f1-4492-8903-cfe8f462baca'); ?>
    <?php $__env->startPush('js'); ?>


    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/testimonial/testimonial.blade.php ENDPATH**/ ?>