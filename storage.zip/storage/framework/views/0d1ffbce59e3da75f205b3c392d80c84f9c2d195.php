<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'paddingBottom'=>$paddingBottom ?? true,
    'all_services'=>$all_services??[],
    'settings'=>$settings??[],
	]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'paddingBottom'=>$paddingBottom ?? true,
    'all_services'=>$all_services??[],
    'settings'=>$settings??[],
	]); ?>
<?php foreach (array_filter(([
	'paddingBottom'=>$paddingBottom ?? true,
    'all_services'=>$all_services??[],
    'settings'=>$settings??[],
	]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section class="
<?php if($paddingBottom): ?>
space-between-sections-y
<?php else: ?>
space-between-sections-t
<?php endif; ?>
 contact-us-section section">
    <div class="res-container">
        <div class="contact-us flex flex-col md:flex-row gap-[118px]">
            <div class="basis-2/5 space-right contact__map ">
                <?php echo $__env->make('front.map.maps',[
                'mapId'=>'map__contact',
                'searchTextField'=>'map__search',
                'lang'=>App()->getLocale(),
                'latitude'=>'30.033333',
                'longitude'=>'31.233334',
                'mapHeight'=>'!h-full'
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="basis-3/5   space-left  contact__form">
				<h2 class="header__text font-bold mb-4"><?php echo e(__('Get A Quote')); ?></h2>
				<p class="small_description text-black font-medium text-lg mb-10"><?php echo e($settings->contact_us_desc); ?></p>

                <form id="Form" method="post" class="w-full" action="<?php echo e(route('web_contacts.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['required' => true,'label' => 'name','name' => 'name','type' => 'text','id' => 'name','placeholder' => __('Enter Your Name ..')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['required' => true,'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('name'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('name'),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('text'),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('name'),'placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Enter Your Name ..'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['required' => true,'label' => 'Email','name' => 'email','id' => 'email','type' => 'email','placeholder' => __('Enter Your Email ..')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['required' => true,'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Email'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('email'),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('email'),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('email'),'placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Enter Your Email ..'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['required' => true,'label' => 'Phone Number','name' => 'phone','id' => 'phone','type' => 'text','placeholder' => __('Enter Your phone ..')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['required' => true,'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Phone Number'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('phone'),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('phone'),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('text'),'placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Enter Your phone ..'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.select','data' => ['multi' => true,'required' => true,'options' => $all_services,'label' => 'Services','name' => 'service_id','id' => 'service_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['multi' => true,'required' => true,'options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($all_services),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Services'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('service_id'),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('service_id')]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textarea','data' => ['required' => true,'label' => 'Messages','name' => 'message','id' => 'message','placeholder' => __('Enter Your Messages ..')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['required' => true,'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Messages'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('message'),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('message'),'placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Enter Your Messages ..'))]); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div class="text-center md:text-left">
                        <div class="form__submit inline-flex md:flex flex-col md:flex-row justify-between items-center md:items-stretch">
                            <div class="form__actions grow inline-flex justify-start items-center gap-5">
                                <div class="icon__parent bg-[#FAF7F0] w-16 h-16  flex items-center justify-center border border-[#D1AA65]  rounded-2xl">
                                    <div class="w-12 h-12 rounded-2xl bg-main relative">
                                        <i class="fa-solid fa-phone-volume text-2xl text-white absolute-center "></i>
                                    </div>
                                </div>

                                <div class="contact__div">
                                    <p class="text-main text-xs uppercase"> <?php echo e(__('Call Now')); ?></p>
                                    <p class="tracking-wider normal__header text-black "><?php echo e($settings->phone); ?></p>
                                </div>

                            </div>
                            <button id="submit_button" form="Form"  type="submit" type="submit" class="submit__btn grow w-full px-10 py-2 mt-5  lg:mt-0 md:max-w-[200px] lg:max-w-[290px] bg-main rounded-2xl text-white capitalize text-center flex-center"><?php echo e(__('Submit')); ?></button>
                        </div>
                    </div>



                </form>


            </div>
        </div>
        <div class="mt-10 text-center md:text-right fixed bottom-[5%] right-[5%] z-[9999] ">
            <a target="_blank" href="https://wa.me/<?php echo e($settings->whatsapp); ?>" class="inline-block text-center  md:text-right ">
                <img src="<?php echo e(asset('front/image/lg-whatsapp.png')); ?>" class="w-12 h-12 md:w-[82px] md:h-[82px] rounded-full shadow-sm">
            </a>
        </div>
    </div>
</section>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/sections/contact-us.blade.php ENDPATH**/ ?>