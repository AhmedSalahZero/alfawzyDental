
<!-- JAVASCRIPT -->
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/node-waves/waves.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/feather-icons/feather.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/pages/plugins/lord-icon-2.1.0.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/plugins.js"></script>

<!-- particles js -->
<script src="<?php echo e(url('assets')); ?>/dashboard/libs/particles.js/particles.js"></script>
<!-- particles app js -->
<script src="<?php echo e(url('assets')); ?>/dashboard/js/pages/particles.app.js"></script>
<!-- password-addon init -->
<script src="<?php echo e(url('assets')); ?>/dashboard/js/pages/password-addon.init.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/js/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/alertify.min.js"></script>

<script>
    $('.lds-hourglass').fadeOut(1000)
</script>

<script>
    window.addEventListener('online', () =>{
        alertify.success('عادت خدمة الانترنت !');
    });
    window.addEventListener('offline', () =>{
        alertify.error('لا يوجد خدمة انترنت !');
    });

</script>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/Auth/layouts/assets/js.blade.php ENDPATH**/ ?>