<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'settings'=>$settings ?? [],
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'settings'=>$settings ?? [],
]); ?>
<?php foreach (array_filter(([
'settings'=>$settings ?? [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<img class="mr-3" src="<?php echo e(asset('front/image/whatsapp.png')); ?>" alt="">
                    <div class="whatsapp__info">
                        <span class="block uppercase text-black font-medium text-sm lg:text-base  lg:font-semibold"><?php echo e(__('Whatsapp')); ?></span>
                        
                        <span class="block capitalize text-black text-xs lg:text-base"><?php echo e(__('Get Immediate Info')); ?></span>
						
                    </div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/social/whatsapp.blade.php ENDPATH**/ ?>