<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('services.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">



        <div class="form-group">
            <label for="image" class="form-control-label"><?php echo e(trans('admin.image')); ?> </label>
            <input type="file" class="dropify" name="image" data-default-file="<?php echo e(get_file($row->image)); ?>" accept="image/*"/>
            <span
                class="form-text text-muted text-center"><?php echo e(trans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>


        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="title" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Title <span class="red-star">*</span></span>
            </label>
            <!--end::Label-->
            <input id="title" required type="text" class="form-control form-control-solid" placeholder="" name="title"
                   value="<?php echo e($row->title); ?>"/>
        </div>






        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <label for="category_service_id" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Category  <span class="red-star">*</span></span>
            </label>
            <select id="category_service_id" name="category_service_id" class="form-control">
                <option selected disabled>Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($row->category_service_id==$category->id): ?>  selected  <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="col-sm-12 pb-3 p-2">
            <label for="desc" class="form-label"> Desc <span class="red-star">*</span> </label>
            <textarea name="desc" id="desc" class="form-control" rows="5"
                      placeholder=""><?php echo e($row->desc); ?></textarea>
        </div>




    </div>
</form>

<script>
    $('.dropify').dropify();

</script>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/CRUDS/services/parts/edit.blade.php ENDPATH**/ ?>