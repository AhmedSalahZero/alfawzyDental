<!--begin::Form-->

<form id="form" enctype="multipart/form-data" method="POST" action="<?php echo e(route('galleries.update',$row->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-4">



        <div class="form-group">
            <label for="file" class="form-control-label">Image Or Video </label>
            <input type="file" class="dropify" name="file" data-default-file="<?php echo e(get_file($row->file)); ?>" accept="image/*"/>
        </div>




    </div>
</form>

<script>
    $('.dropify').dropify();

</script>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/CRUDS/galleries/parts/edit.blade.php ENDPATH**/ ?>