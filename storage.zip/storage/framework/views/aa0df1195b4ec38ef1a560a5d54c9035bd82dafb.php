<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'title'=>$title ,
'link'=>$link,
'subMenu'=>$subMenu??[]
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'title'=>$title ,
'link'=>$link,
'subMenu'=>$subMenu??[]
]); ?>
<?php foreach (array_filter(([
'title'=>$title ,
'link'=>$link,
'subMenu'=>$subMenu??[]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li x-data="{isMenuIsOpen:false}" x-cloak class="border-b  pb-3 group/li-mobile border-gray-200 transition-all duration-300 ease-in-out">
    <a @click="isMenuIsOpen=!isMenuIsOpen" href="<?php echo e($link); ?>" class="group-hover/li-mobile:text-main transition-all duration-300 ease-in ">
        <span><?php echo e($title); ?></span>
        <i class="fa-solid fa-chevron-down text-xs"></i>
    </a>
    <?php if(count($subMenu)): ?>
    <ul
	class="py-3 pl-3"
	 x-show="isMenuIsOpen" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="">
        <?php $__currentLoopData = $subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$subMenuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li  class="pb-3 group/li-mobile-2 transition-all duration-300 ease-in-out">
            <a  href="<?php echo e($subMenuItem['link']); ?>" class="group-hover/li-mobile-2:text-main text-gray-200 transition-all duration-300 ease-in capitalize">
                <span><?php echo e($subMenuItem['title']); ?></span>
            </a>
        </li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</li>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/links/mobile-nav-link.blade.php ENDPATH**/ ?>