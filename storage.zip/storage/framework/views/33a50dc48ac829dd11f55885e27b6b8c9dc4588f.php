<?php $__env->startSection('title'); ?>

    Contact Us
<?php $__env->stopSection(); ?>
<?php $__env->startPush('content'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banners.single-banner','data' => ['lg' => true,'title' => __('Contact Us')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banners.single-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['lg' => true,'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Contact Us'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<section class="contact-us-info-section section -translate-y-1/2 md:-translate-y-[60%] mb-[-930px] md:mb-[-500px]">
    <div class="res-container">
        <div class="main-branches-elements">
            <div class="main-branches grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-20 ">
                <div class="main-branch-info bg-white shadow-lg rounded-2xl max-w-[380px] py-5 px-6 space-y-2">
                    <div class="branch-icon bg-main w-8 h-8 md:w-11 md:h-11 rounded-2xl  flex-center">
                        <i class="text-white icon-size fa-solid fa-house"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-black "><?php echo e($settings->footer_title1); ?></h3>
                    <div class="!text-sm md:!text-lg description__paragraph !text-[#8A8A8A]"><?php echo $settings->footer_desc1; ?></div>

                </div>

                <div class="main-branch-info bg-white shadow-lg rounded-2xl max-w-[380px] py-5 px-6 space-y-2">
                    <div class="branch-icon bg-main w-8 h-8 md:w-11 md:h-11 rounded-2xl  flex-center">
                        <i class="text-white icon-size fa-solid fa-house"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-black "><?php echo e($settings->footer_title2); ?></h3>
                    <div class="!text-sm md:!text-lg description__paragraph !text-[#8A8A8A]"><?php echo $settings->footer_desc2; ?></div>

                </div>


                <div class="main-branch-info bg-white shadow-lg rounded-2xl max-w-[380px] py-5 px-6 space-y-2">
                    <div class="branch-icon bg-main w-8 h-8 md:w-11 md:h-11 rounded-2xl  flex-center">
                        <i class="text-white icon-size fa-solid fa-envelope"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-black ">Our Email Address</h3>
                    <div class="!text-sm md:!text-lg description__paragraph !text-[#8A8A8A]"><?php echo e($settings->email); ?></div>

                </div>
            </div>
        </div>
        <div class="main-branches-google py-10 px-2 md:px-10 flex flex-col md:flex-row items-start  bg-white shadow-sm md:rounded-[48px] mt-20">
            <div class="basis-1/3">
                <img src="<?php echo e(get_file($settings->contact_us_image)); ?>" class="max-w-full" alt="">
            </div>
            <div class="basis-2/3  max-w-[666px]">
                <p class="text-lg leading-8">
                   <?php echo e($settings->contact_us_desc); ?>

                </p>
				<div class="map__link mt-5 ">
					<a target="_blank" href="<?php echo e($settings->contact_us_link); ?>" class=" inline-flex items-center justify-center min-h-[64px] w-[244px] gap-2 capitalize bg-main text-white rounded-2xl shadow-sm">
						<i class="icon-size fa-brands fa-google  "></i>
						<span class="text-lg font-semibold "><?php echo e(__('Map Link')); ?></span>
					</a>
				</div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('front.home.parts.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

    <?php echo $__env->make('front.contact.contactJs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/contact/contact.blade.php ENDPATH**/ ?>