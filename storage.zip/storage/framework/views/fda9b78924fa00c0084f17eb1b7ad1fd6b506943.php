<section class="space-between-sections-t mt-20 md:mt-64">
    <div class="res-container overflow-x-hidden">
        <div class="testimonal-parent flex flex-col md:flex-row items-center relative justify-between gap-10">
            <div class=" description relative basis-1/3 max-w-[300px] z-[2] mt-[-100px]">
                <div class="max-w-[274px] ">
                    <h1 class="main__title__bold mb-10"><?php echo e(__('What Our Patients Say')); ?></h1>
                    <a href="<?php echo e($settings->review_link); ?>"  target="_blank" class="btn bg-main !inline-flex items-center justify-between text-white ">
                        <i class="fa-brands fa-google bg-main mr-2 rounded-2xl "></i>
                        <span class="normal-text whitespace-nowrap "><?php echo e(__('Read our Reviews')); ?></span>
                    </a>
                </div>
            </div>
            <div class="testimonals-elements grow relative z-1 ">

                <div class="swiper testimonial-swiper   w-screen ">
                    <div class="swiper-wrapper">

                        
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.testimonial.testimonial','data' => ['reviews' => $oddReview]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimonial.testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['reviews' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($oddReview)]); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        

                    </div>
                </div>

                <div class="swiper testimonial-swiper2  mt-[-9rem] w-screen overflow-hidden">
                    <div class="swiper-wrapper">

                        
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.testimonial.testimonial','data' => ['reviews' => $evenReviews]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimonial.testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['reviews' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($evenReviews)]); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        

                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/home/parts/review.blade.php ENDPATH**/ ?>