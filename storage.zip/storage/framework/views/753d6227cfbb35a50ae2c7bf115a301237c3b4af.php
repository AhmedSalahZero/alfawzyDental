<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'title'=>$title,
	'lg'=>$lg ?? false 
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'title'=>$title,
	'lg'=>$lg ?? false 
]); ?>
<?php foreach (array_filter(([
	'title'=>$title,
	'lg'=>$lg ?? false 
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section class="banner single-banner">
	
		<div class="banner__content
		<?php if($lg): ?>
	 	min-h-[1060px] md:min-h-[709px]
		flex items-start pt-20 justify-center
		<?php else: ?>
		min-h-[227px]
		flex-center
		<?php endif; ?> 
		   bg-[#CDCDCD]">
			<div class="banner__title ">
				<h3 class="!uppercase main__title__bold "><?php echo e($title); ?></h3>
			</div>
		</div>
	
</section>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/banners/single-banner.blade.php ENDPATH**/ ?>