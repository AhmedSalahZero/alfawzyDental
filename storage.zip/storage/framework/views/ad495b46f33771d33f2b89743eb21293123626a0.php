<!-- ========== App Menu ========== -->

<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <a href="<?php echo e(route('admin.index')); ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="22">
                    </span>
            <span class="logo-lg">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="40">
                    </span>
        </a>
        <!-- Light Logo-->
        <a href="<?php echo e(route('admin.index')); ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="22">
                    </span>
            <span class="logo-lg">
                        <img src="<?php echo e(get_file(setting()->logo_header)); ?>" alt="" height="40">
                    </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">

            <div id="two-column-menu">
            </div>
            <ul class="navbar-nav" id="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('admin.index')); ?>">
                        <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Dashboard</span>
                    </a>
                </li> <!-- end Dashboard Menu -->



                    <li class="nav-item">
                        <a class="nav-link menu-link" href="<?php echo e(route('admins.index')); ?>">
                            <i class="fa fa-user-secret"></i> <span data-key="t-dashboards">Admins</span>
                        </a>
                    </li> <!-- end Dashboard Menu -->

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('sliders.index')); ?>">
                        <i class="fa fa-camera"></i> <span data-key="t-dashboards">Sliders</span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('about_us.index')); ?>">
                        <i class="fa fa-info"></i> <span data-key="t-dashboards">About Us </span>
                    </a>
                </li> <!-- end Dashboard Menu -->



                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('faq_questions.index')); ?>">
                        <i class="fa fa-question-circle"></i> <span data-key="t-dashboards">Faq Questions</span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('reviews.index')); ?>">
                        <i class="fa fa-star"></i> <span data-key="t-dashboards">Review</span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('patients.index')); ?>">
                        <i class="fa fa-medkit"></i> <span data-key="t-dashboards">Patients</span>
                    </a>
                </li> <!-- end Dashboard Menu -->

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('authors.index')); ?>">
                        <i class="fa fa-user"></i> <span data-key="t-dashboards">Author</span>
                    </a>
                </li> <!-- end Dashboard Menu -->

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('blogCategories.index')); ?>">
                        <i class="fa fa-list"></i> <span data-key="t-dashboards">Blog Category</span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('blogs.index')); ?>">
                        <i class="fa fa-blog"></i> <span data-key="t-dashboards">Blogs </span>
                    </a>
                </li> <!-- end Dashboard Menu -->



                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('serviceCategories.index')); ?>">
                        <i class="fa fa-list"></i> <span data-key="t-dashboards">Service Categories </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('services.index')); ?>">
                        <i class="fa fa-wrench"></i> <span data-key="t-dashboards">Services </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('categoryMembers.index')); ?>">
                        <i class="fa fa-list"></i> <span data-key="t-dashboards">Our Team Categories </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('members.index')); ?>">
                        <i class="fa fa-user-doctor"></i> <span data-key="t-dashboards">Our Teams </span>
                    </a>
                </li> <!-- end Dashboard Menu -->



                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('galleries.index')); ?>">
                        <i class="fa fa-camera"></i> <span data-key="t-dashboards">Galleries </span>
                    </a>
                </li> <!-- end Dashboard Menu -->

                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('partners.index')); ?>">
                        <i class="fa fa-handshake"></i> <span data-key="t-dashboards">Partners </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('contacts.index')); ?>">
                        <i class="fa fa-envelope"></i> <span data-key="t-dashboards">Contacts </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('settings.index')); ?>">
                        <i class="fa fa-cog"></i> <span data-key="t-dashboards">Settings </span>
                    </a>
                </li> <!-- end Dashboard Menu -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="<?php echo e(route('dental_tourism.index')); ?>">
                        <i class="fa fa-tooth"></i> <span data-key="t-dashboards">Dental Tourism </span>
                    </a>
                </li> <!-- end Dashboard Menu -->



            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->
<!-- Vertical Overlay-->


<div class="vertical-overlay"></div>




<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/layouts/inc/sidebar.blade.php ENDPATH**/ ?>