<?php $__env->startSection('title'); ?>

    Blog
<?php $__env->stopSection(); ?>
<?php $__env->startPush('content'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banners.single-banner','data' => ['title' => __('blog')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banners.single-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('blog'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <section class="blogs-section space-between-sections-y ">
        <div class="res-container">
            <div class="blog__content ">
                <h3 class="text-center text-4xl font-bold capitalize mb-16"><?php echo e(__('stay updated with our latests news')); ?></h3>
                <div class="blogs grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-y-20 gap-x-10 justify-center items-center">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.blogs.blog','data' => ['img' => get_file($blog->image),'date' => date('d M', strtotime($blog->created_at)),'title' => substr($blog->title, 0, 30),'subtitle' => substr($blog->brief, 0, 30),'id' => $blog->id,'description' => substr($blog->desc, 0, 30)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blogs.blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['img' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(get_file($blog->image)),'date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(date('d M', strtotime($blog->created_at))),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->title, 0, 30)),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->brief, 0, 30)),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->id),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->desc, 0, 30))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/blog/blogs.blade.php ENDPATH**/ ?>