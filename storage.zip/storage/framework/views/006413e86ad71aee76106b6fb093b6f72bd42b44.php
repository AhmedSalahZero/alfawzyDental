<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'placeholder'=>$placeholder ?? '',
'type'=>$type ??'text',
'required'=>$required ?? false
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'placeholder'=>$placeholder ?? '',
'type'=>$type ??'text',
'required'=>$required ?? false
]); ?>
<?php foreach (array_filter(([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'placeholder'=>$placeholder ?? '',
'type'=>$type ??'text',
'required'=>$required ?? false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full md:w-1/2 px-3 mb-2">
    <label class="block uppercase tracking-wide text-gray-500 text-xs font-bold mb-2" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

        <?php if($required): ?>
        <span class="text-red-500">*</span>
        <?php endif; ?>
    </label>
    <input <?php if($required): ?> required <?php endif; ?> id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="appearance-none  block w-full bg-white text-gray-700 border rounded-2xl min-h-[56px]
	 pl-[20px] py-3 px-4 mb-3 leading-tight focus:outline-none " type="<?php echo e($type); ?>" placeholder="<?php echo e($placeholder); ?>">
    
</div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/form/input.blade.php ENDPATH**/ ?>