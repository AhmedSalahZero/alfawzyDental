<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
	'link'=>$link ,
	'title'=>$title
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
	'link'=>$link ,
	'title'=>$title
]); ?>
<?php foreach (array_filter(([
	'link'=>$link ,
	'title'=>$title
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="py-2  group/li2 block ">
									<a href="<?php echo e($link); ?>" class="group-hover/li2:text-main text-black capitalize transition-colors duration-300"><?php echo e($title); ?></a>
								</li>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/links/sub-menu-item.blade.php ENDPATH**/ ?>