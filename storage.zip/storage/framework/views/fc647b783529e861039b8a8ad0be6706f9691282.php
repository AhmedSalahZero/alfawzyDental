<div  x-cloak x-show="showSideBar" class="hidden md:flex bg-white flex-col h-full p-3 w-60 dark:bg-gray-900 dark:text-gray-100   right-0 z-[99999999999999999] top-0  bottom-0 fixed">
	<div class="space-y-3">
		<div class="flex items-center justify-between">
			<h2 class="opacity-0">Home</h2>
			<button class="p-2">
				<svg @click="showSideBar=!showSideBar" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5 fill-current dark:text-gray-100">
					<rect width="352" height="32" x="80" y="96"></rect>
					<rect width="352" height="32" x="80" y="240"></rect>
					<rect width="352" height="32" x="80" y="384"></rect>
				</svg>
			</button>
		</div>
		
		<div class="flex-1">
			<ul class="pt-2 pb-4 space-y-1 text-sm">
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('home.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Home</span>
					</a>
				</li>
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('web_about.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>About Us</span>
					</a>
				</li>
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('web_services.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Our Services</span>
					</a>
				</li>
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('web_partners.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Our  Partener</span>
					</a>
				</li>
				<li class="rounded-sm dark:bg-gray-800 dark:text-gray-50">
					<a rel="noopener noreferrer" href="<?php echo e(route('web_gallery.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Gallery</span>
					</a>
				</li>
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('dental.tourism.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Dental Tourism</span>
					</a>
				</li>
				<li class="rounded-sm">
					<a rel="noopener noreferrer" href="<?php echo e(route('web_contacts.index')); ?>" class="flex items-center p-2 space-x-3 rounded-md">
						
						<span>Contact Us</span>
					</a>
				</li>
			</ul>
		</div>
	</div>
	
</div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/sidebar.blade.php ENDPATH**/ ?>