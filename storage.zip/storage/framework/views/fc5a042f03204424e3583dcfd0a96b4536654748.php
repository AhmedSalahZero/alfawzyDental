<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'required'=>$required ?? false,
'options'=>$options,
''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'required'=>$required ?? false,
'options'=>$options,
''
]); ?>
<?php foreach (array_filter(([
'label'=>$label,
'id'=>$id ,
'name'=>$name,
'required'=>$required ?? false,
'options'=>$options,
''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

 <div class="w-full md:w-1/2 px-3 mb-2">
      <label class="block uppercase tracking-wide text-gray-500 text-xs font-bold mb-2" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

      </label>
      <div class="relative">
        <select name="<?php echo e($name); ?>" class="block min-h-[56px]  pl-[20px] appearance-none w-full bg-white border border-gray-200 text-gray-700 py-3  pr-8 rounded-2xl leading-tight focus:outline-none  focus:border-gray-500" id="<?php echo e($id); ?>">
          <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  <option value="<?php echo e($option->id); ?>"><?php echo e($option->title); ?></option>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="pointer-events-none pr-[20px] absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
          <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
        </div>
      </div>
    </div>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/components/form/select.blade.php ENDPATH**/ ?>