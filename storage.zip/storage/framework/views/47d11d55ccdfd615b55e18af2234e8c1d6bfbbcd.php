<?php $__env->startSection('title'); ?>

    Blog
<?php $__env->stopSection(); ?>
<?php $__env->startPush('content'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banners.single-banner','data' => ['title' => $blog->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banners.single-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->title)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<section class="section space-between-sections-y">
    <div class="res-container">
        <div class="blog__header mb-10">
            <div class="max-w-[950px] space-y-4 mx-auto">
                <h1 class="text-main font-bold text-xs capitalize"><?php echo e($blog->category->title??''); ?></h1>
                <p class="max-w-[682px] text-5xl font-semibold capitalize leading-[60px]"><?php echo e($blog->title); ?></p>
                <div class="bloger__images flex gap-3 items-center mb-5">
                    <div class="bloger__img">
                        <img src="<?php echo e(get_file($blog->author->image??'')); ?>" class="w-12 h-12 rounded-full " alt="">
                    </div>
                    <div class="bloger__infos">
                        <p class="bloger__name font-bold "><?php echo e($blog->author->name??''); ?></p>
                        <p class="blogger__date text-gray-500 text-xs "><?php echo e(date('d M', strtotime($blog->created_at))); ?></p>
                    </div>
                </div>
                <div class="text-gray-500 leading-8 font-medium ">
                    <p><?php echo e($blog->brief); ?></p>
                </div>
            </div>
        </div>

        <div class="blog__lg-img mb-10">
            <img src="<?php echo e(get_file($blog->image)); ?>" class="max-w-full mx-auto rounded-[32px]" alt="">
        </div>

        <div class="max-w-[950px] leading-8 mx-auto text-gray-500 ">
            <?php echo e($blog->desc); ?>

  </div>

        <div class="stay-updated mt-20">
            <h3 class="capitalize font-bold text-3xl mb-8 text-center "><?php echo e(__('stay updated with our latests news')); ?></h3>
            <div class="blogs grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-y-20 gap-x-10 justify-center items-center">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.blogs.blog','data' => ['img' => get_file($blog->image),'date' => date('d M', strtotime($blog->created_at)),'title' => substr($blog->title, 0, 30),'subtitle' => substr($blog->brief, 0, 30),'description' => substr($blog->desc, 0, 30),'id' => $blog->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blogs.blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['img' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(get_file($blog->image)),'date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(date('d M', strtotime($blog->created_at))),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->title, 0, 30)),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->brief, 0, 30)),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(substr($blog->desc, 0, 30)),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->id)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>


</section>




<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/blog/blog.blade.php ENDPATH**/ ?>