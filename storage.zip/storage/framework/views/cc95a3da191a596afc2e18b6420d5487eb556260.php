<form action="<?php echo e(route('admins.update',$admin->id)); ?>" method="post" id="EditForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>

    <div class="row g-4">
        <div class="form-group">
            <label for="name" class="form-control-label"><?php echo e(trans('admin.image')); ?></label>
            <input type="file" class="dropify" name="image" data-default-file="<?php echo e(get_file($admin->image)); ?>" accept="image/*"/>
            <span class="form-text text-muted text-center"><?php echo e(trans('admin.Only the following formats are allowed: jpeg, jpg, png, gif, svg, webp, avif.')); ?></span>
        </div>
        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(trans('admin.name')); ?></span>
            </label>
            <!--end::Label-->
            <input type="text" required class="form-control form-control-solid" placeholder="<?php echo e(trans('admin.name')); ?>"  name="name" value="<?php echo e($admin->name); ?>"/>
        </div>

        <!--end::Input group-->
        <!--begin::Input group-->
        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1"><?php echo e(trans('admin.email')); ?></span>
            </label>
            <!--end::Label-->
            <input type="email" required class="form-control form-control-solid"  placeholder=" <?php echo e(trans('admin.email')); ?>" name="email" value="<?php echo e($admin->email); ?>"/>
        </div>

        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label for="phone" class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">Phone</span>
            </label>
            <!--end::Label-->
            <input  id="phone" type="text" class="form-control form-control-solid" placeholder=" " name="phone" value="<?php echo e($admin->phone); ?>"/>
        </div>



        <div class="d-flex flex-column mb-7 fv-row col-sm-6">
            <!--begin::Label-->
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required mr-1">  <?php echo e(trans('admin.password')); ?></span>
            </label>
            <!--end::Label-->
            <input type="password" class="form-control form-control-solid" placeholder="  <?php echo e(trans('admin.password')); ?> " name="password" value=""/>
        </div>





    </div>
</form>
<script>
    $('.dropify').dropify();

</script>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/CRUDS/admin/parts/show.blade.php ENDPATH**/ ?>