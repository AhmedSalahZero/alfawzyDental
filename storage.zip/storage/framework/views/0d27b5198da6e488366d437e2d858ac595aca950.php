<section class="space-between-sections-y">
    <div class="res-container mt-96 md:mt-36">
        <div
            class="online-consultings flex justify-between text-center md:text-left items-center flex-col md:flex-row  gap-20">
            <div class="online-consulting ">
                <h4 class="main__title mb-5"><?php echo e(__('Online Consulting')); ?></h4>
                <h2 class="sub__title max-w-[386px] mb-5"><?php echo e(__('Make online and live Consultation easily.')); ?></h2>
                <a target="_blank" href="<?php echo e(getWhatsappApi($settings->whatsapp)); ?>" class="whatsapp__container inline-flex items-center justify-center social-whatsapp">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social.whatsapp','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('social.whatsapp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </a>

            </div>
            <div class="online-consulting">
                <img src="<?php echo e(asset('front/image/doctors.png')); ?>">
            </div>
            <div class="online-consulting">
                <img src="<?php echo e(asset('front/image/doctor.png')); ?>">

            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/home/parts/doctor.blade.php ENDPATH**/ ?>