<meta charset="utf-8" />
<title><?php echo e(setting()->app_name); ?> -<?php echo $__env->yieldContent('title'); ?> </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="Themesbrand" name="author" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(get_file($settings->fave_icon)); ?>">

<!-- jsvectormap css -->


<!--Swiper slider css-->


<!-- Layout config Js -->
<script src="<?php echo e(url('assets')); ?>/dashboard/js/layout.js"></script>
<!-- Bootstrap Css -->
<?php if(app()->getLocale()=='ar'): ?>
    <link href="<?php echo e(url('assets')); ?>/dashboard/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css" />

<?php else: ?>
    <link href="<?php echo e(url('assets')); ?>/dashboard/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<?php endif; ?>
<!-- Icons Css -->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<?php if(app()->getLocale()=='ar'): ?>

<link href="<?php echo e(url('assets')); ?>/dashboard/css/app-rtl.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(url('assets')); ?>/dashboard/css/custom-rtl.min.css" rel="stylesheet" type="text/css" />

<?php else: ?>

    <link href="<?php echo e(url('assets')); ?>/dashboard/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('assets')); ?>/dashboard/css/custom.min.css" rel="stylesheet" type="text/css" />

<?php endif; ?>

<!-- custom Css-->
<link href="<?php echo e(url('assets')); ?>/dashboard/css/jquery.fancybox.min.css" rel="stylesheet" type="text/css" />

<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" rel="stylesheet" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/css/alertify.min.css" />
<!-- include a theme -->
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/dashboard/backEndFiles/alertify/css/themes/default.min.css" />

<style>
    .nav-link{
        position: relative;
    }
    .newAlert{
        position: absolute;
        display: none;
        right: 20px;
        top: 10px;
        height: 10px;
        min-width:10px;
        background-color:#E5AD4C;
        border-radius: 100px;
        /*display: inline-block;*/
        transition: all .3s ease-in-out;
        box-shadow: 0px 0px 0px 10px #E5AD4C70;
        animation: mohamedGamal infinite 1s;
    }
    .newAlertLeft{
        position: absolute;
        display: none;
        left: 20px;
        top: 10px;
        height: 10px;
        min-width:10px;
        background-color: #E5AD4C;
        border-radius: 100px;
        /*display: inline-block;*/
        transition: all .3s ease-in-out;
        box-shadow: 0px 0px 0px 10px #E5AD4C70;
        animation: mohamedGamal infinite 1s;
    }
    .newAlertDiv{
        position: relative;
    }
    .newAlertDiv .newAlert{
        top: 30px;

    }
    @keyframes mohamedGamal {
        0% {
            box-shadow: 0px 0px 0px 0px #E5AD4C70;
        }
        50%{
            box-shadow: 0px 0px 0px 10px #E5AD4C70;
        }
        100%{
            box-shadow: 0px 0px 0px 0px #E5AD4C70;
        }
    }
     .red-star {
         color: red;
     }
</style>
<link rel="stylesheet" media="all" href="<?php echo e(asset('assets/cute-alert-master/style.css')); ?>"/>

<?php echo $__env->yieldContent('css'); ?>

<?php echo $__env->make('layouts.loader.loaderCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/layouts/assets/css.blade.php ENDPATH**/ ?>