<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script>
                © <a href="#">Elsdodey.
                </a>
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <a href="#">Elsdodey
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/Admin/layouts/inc/footer.blade.php ENDPATH**/ ?>