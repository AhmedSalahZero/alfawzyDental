<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(setting()->app_name); ?> -<?php echo $__env->yieldContent('title'); ?> </title>

    <link rel="stylesheet" href="<?php echo e(asset('front/icons/fontawesome-6-4-2/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/scss/main.css')); ?>">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" type="text/css"/>

    <link rel="stylesheet" href="<?php echo e(url('front')); ?>/alertify/css/alertify.min.css"/>
    <!-- include a theme -->
    <link rel="stylesheet" href="<?php echo e(url('front')); ?>/alertify/css/themes/default.min.css"/>
    <link rel="shortcut icon" href="<?php echo e(get_file($settings->fave_icon)); ?>">

    <style>


    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body x-data="{showSideBar:false}" class="overflow-x-hidden ">

<div class="fixed-video">
    <video loop="" autoplay="" playsinline="" muted="" preload="auto" controlslist="nodownload"
           disablepictureinpicture="">
        <source src="<?php echo e(get_file($settings->video_footer)); ?>" type="video/mp4">
    </video>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<a target="_blank" href="<?php echo e(getWhatsappApi($settings->whatsapp)); ?>"
    class="inline-flex md:hidden z-[999] fixed md:static bottom-0 md:bottom-auto left-1/2 md:left-auto w-full md:w-auto -translate-x-1/2 md:-translate-x-0  md:z-0    whatsapp__container  items-center justify-center social-whatsapp mr-8">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social.whatsapp','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('social.whatsapp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</a>
<header class="
	z-50
	<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
	h-[90vh]
	<?php else: ?>
	h-[123px]

	<?php endif; ?>
	 header
	  relative
	   "  >
    <?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
        <div class="dark-layer pointer-events-none h-full w-full absolute z-[5]"
             style="background-image:linear-gradient(180deg, #00000032 20%, #00000000 58%)">

        </div>
    <?php endif; ?>
    <div class="res-container h-full !items-start">
        <div class="header__menu z-[5] flex justify-between
			items-center
			<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
			pt-4
			<?php else: ?>
			self-center
			<?php endif; ?>

			  ">
            <div class="logo__container flex flex-col gap-20">
                <a href="<?php echo e(route('home.index')); ?>" class="logo__image max-w-[]">
                    <img class="w-[40px]   lg:h-[75px] lg:w-auto" src="<?php echo e(get_file($settings->logo_header)); ?>"
                         alt="<?php echo e(env('APP_NAME	')); ?>">
                </a>

            </div>

            <ul x-cloak
                class="grow   text-center hidden md:flex  md:space-x-3 lg:space-x-4 items-center justify-center  ">


                <li class="group/li relative" x-data="{isOpen:false}"

					 @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('home.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        <?php echo e(__('Home')); ?>

                    </a>
                </li>



                <li class="group/li relative " x-data="{isOpen:false}"
				@mouseleave="isOpen = false"
				 @mouseover="isOpen = true"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_about.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm inline pb-8 items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        About
                        <i class="fa-solid fa-chevron-down text-xs"></i>
                    </a>
                    <ul x-cloak x-show="isOpen" x-transition:enter="transition ease-out duration-100"
                        x-transition:enter-start="transform opacity-0 scale-95"
                        x-transition:enter-end="transform opacity-100 scale-100"
                        x-transition:leave="transition ease-in duration-75"
                        x-transition:leave-start="transform opacity-100 scale-100"
                        x-transition:leave-end="transform opacity-0 scale-95"
                        class="submenu px-5 w-52 bg-white    rounded-md shadow-md  absolute top-9 left-1/2 -translate-x-1/2 z-10 ">

                        <li class="py-2  group/li2 block ">
                            <a href="<?php echo e(route('web_about.index')); ?>"
                               class="group-hover/li2:text-main text-black capitalize transition-colors duration-300">Our
                                Team</a>
                        </li>
                        <li class="py-2  group/li2 block ">
                            <a href="<?php echo e(route('web_about.index')); ?>"
                               class="group-hover/li2:text-main text-black capitalize transition-colors duration-300">Our
                                Partners</a>
                        </li>


                    </ul>
                </li>



                <li class="group/li relative " x-data="{isOpen:false}"
                    @mouseleave="isOpen = false"
                    @mouseover="isOpen = true"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_services.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        Our Services
                        <i class="fa-solid fa-chevron-down text-xs"></i>

                    </a>
                    <ul x-cloak x-show="isOpen" x-transition:enter="transition ease-out duration-100"
                        x-transition:enter-start="transform opacity-0 scale-95"
                        x-transition:enter-end="transform opacity-100 scale-100"
                        x-transition:leave="transition ease-in duration-75"
                        x-transition:leave-start="transform opacity-100 scale-100"
                        x-transition:leave-end="transform opacity-0 scale-95"
                        class="submenu px-5 w-52 bg-white    rounded-md shadow-md  absolute top-9 left-1/2 -translate-x-1/2 z-10 ">
                        <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links.sub-menu-item','data' => ['link' => route('web_category_services.index',$category->id),'title' => $category->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links.sub-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('web_category_services.index',$category->id)),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->title)]); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </ul>

                </li>


                <li class="group/li relative" x-data="{isOpen:false}"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('dental.tourism.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        Dental Tourism
                    </a>
                </li>


                <li class="group/li relative" x-data="{isOpen:false}"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_gallery.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        Gallery
                    </a>
                </li>


                <li class="group/li relative" x-data="{isOpen:false}"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_faq.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        FAQs
                    </a>
                </li>



                <li class="group/li relative" x-data="{isOpen:false}"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_blogs.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        Blog
                    </a>
                </li>


                <li class="group/li relative" x-data="{isOpen:false}"
                     @click.away="isOpen=false">
                    <a @click="isOpen=!isOpen" href="<?php echo e(route('web_contacts.index')); ?>" class="
						<?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
						text-white
						<?php else: ?>
						text-black
						<?php endif; ?>
						 text-nowrap capitalize text-sm flex items-center lg:text-base md:gap-1 lg:font-semibold  group-hover/li:text-main transition-colors duration-300">
                        Contacts
                    </a>
                </li>




            </ul>
            <a target="_blank"  href="<?php echo e(getWhatsappApi($settings->whatsapp)); ?>"
                class="hidden md:inline-flex fixed md:static bottom-0 md:bottom-auto left-1/2 md:left-auto w-full md:w-auto -translate-x-1/2 md:-translate-x-0 z-50 md:z-0    whatsapp__container  items-center justify-center social-whatsapp mr-8">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social.whatsapp','data' => ['settings' => $settings]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('social.whatsapp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['settings' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($settings)]); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </a>
            <div class="w-10 h-10 rounded-lg bg-white hidden md:flex md:justify-center md:items-center  cursor-pointer"
                 @click="showSideBar=!showSideBar">
                <i class="fa-solid fa-bars-staggered text-black icon-size"></i>
            </div>


            <div class="bar__menu relative z-20   md:hidden " x-data="{mobileMenuIsOpen:false }">
                <div class="bar__ment-content  " @click.away="mobileMenuIsOpen=false">
                    <div @click="mobileMenuIsOpen=!mobileMenuIsOpen" class="cursor-pointer">
                        <i class="fa-solid fa-bars-staggered text-white "></i>
                    </div>
                    <div class="fixed  top-0 left-0 w-[70vw] h-screen bg-white  "
                         x-transition:enter="transition ease-out duration-100"
                         x-transition:enter-start="transform opacity-0 scale-95"
                         x-transition:enter-end="transform opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75"
                         x-transition:leave-start="transform opacity-100 scale-100"
                         x-transition:leave-end="transform opacity-0 scale-95" x-show="mobileMenuIsOpen">
                        <ul class="pt-10 px-3  flex flex-col gap-2 ">
                            <?php $__currentLoopData = getPages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageName=>$navArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links.mobile-nav-link','data' => ['subMenu' => [['title'=>'first','link'=>'#'],['title'=>'second','link'=>'#']],'title' => $navArr['title'],'link' => $navArr['url']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links.mobile-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subMenu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['title'=>'first','link'=>'#'],['title'=>'second','link'=>'#']]),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navArr['title']),'link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navArr['url'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <ul class="flex space-between items-center pt-4">
                            <?php $__currentLoopData = getSocialIcons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iconName=>$iconArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links.social-links','data' => ['iconSize' => 'text-lg','iconName' => $iconName,'iconClass' => $iconArr['icon'],'iconLink' => $iconArr['link']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links.social-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon-size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('text-lg'),'iconName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconName),'iconClass' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconArr['icon']),'iconLink' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconArr['link'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div @click="mobileMenuIsOpen=false"
                             class="remove border border-gray-300  absolute top-3 right-3 h-6 flex-center  w-6 rounded-full cursor-pointer  bg-white">
                            <i class="fa-solid fa-xmark text-black  icon-size "></i>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php if(isset($showHeaderBanner) && $showHeaderBanner): ?>
            <div class="header__main-content flex items-center ">

                <div class="hidden md:block icons  z-[12]">
                    <ul class="flex  flex-col space-y-7 ">
                        <?php $__currentLoopData = [
                        __('Instagram')=>[
                        'icon'=>'fa-brands fa-instagram',
                        'link'=>$settings->instagram
                        ],
                        __('Facebook')=>[
                        'icon'=>'fa-brands fa-facebook-f',
                        'link'=>$settings->facebook
                        ],
                        __('Snapchat')=>[
                        'icon'=>'fa-brands fa-snapchat',
                        'link'=>$settings->snapchat
                        ],
                        __('Google')=>[
                        'icon'=>'fa-brands fa-google',
                        'link'=>$settings->gmail,
                        ],
                        __('Tiktok')=>[
                        'icon'=>'fa-brands fa-tiktok',
                        'link'=>$settings->tiktok,
                        ]
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iconName=>$iconArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.links.social-links','data' => ['iconName' => $iconName,'iconClass' => $iconArr['icon'],'iconLink' => $iconArr['link']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('links.social-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['iconName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconName),'iconClass' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconArr['icon']),'iconLink' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconArr['link'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>

                <div class=" grow flex flex-col items-center self-end  gap-24 ">
                    <div class="swiper header-swiper">
                        <div class="swiper-wrapper">
                            <?php if(isset($sliders)): ?>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="absolute top-0 right-0 left-0 bottom-0 bg-no-repeat bg-cover "
                                             style="background-image:url('<?php echo e(get_file($slider->image)); ?>')">
                                            


                                        </div>
                                        <h1 class="absolute-center header__text  text-center  text-white uppercase font-semibold">
                                            <?php echo e($slider->title); ?>

                                        </h1>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div
                        class="header__contact z-[8]  items-stretch md:items-center flex flex-col md:flex-row  space-x-0 md:space-x-10 space-y-7 md:space-y-0">
                        <?php $__currentLoopData = [
                        [
                        'icon'=> 'fa-solid fa-phone-volume',
                        'title'=>__('call now'),
                        'value'=>__($settings->phone)
                        ],
                        [
                        'icon'=> 'fa-solid fa-envelope',
                        'title'=>__('email'),
                        'value'=>__($settings->email)
                        ]
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactInfoArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div
                                class="contact__element rounded-2xl px-2  sm:px-4  h-[76px] py-2 bg-white flex space-x-1 sm:space-x-3 items-center  ">
                                <div class="contact-icon bg-main rounded-2xl  px-1 py-2 w-[42px] h-[42px] flex-center ">
                                    <i class="<?php echo e($contactInfoArr['icon']); ?> text-white icon-size    "></i>
                                </div>
                                <div class="contact__description">
                                    <p class="tracking-tight text-black xs:font-normal sm:font-medium md:font-semibold text-xs  md:text-base uppercase "><?php echo e($contactInfoArr['title']); ?></p>
                                    <p class="tracking-tight text-black xs:font-normal sm:font-medium md:font-medium text-xs  md:text-base uppercase "><?php echo e($contactInfoArr['value']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>
        <?php endif; ?>


    </div>
</header>
<?php echo $__env->yieldPushContent('content'); ?>

<footer class="pt-20 h-[425px] bg-cover "
        style="background:url('<?php echo e(asset('front/image/footer.jpg')); ?>'),lightgray 50%;background-position:left center; ">
    <div class="res-container">
        <div class="footer__content flex flex-col md:flex-row ">
            <div class="footer__logos w-full md:w-1/3 flex space-y-10 items-center justify-between flex-col  h-full">
                <div class="footer__logo ">
                    <img src="<?php echo e(get_file($settings->logo_footer)); ?>"
                         class=" w-[137px] h-[158px] md:w-[138px] md:h-[195px] " alt="">
                </div>
                <ul class="footer__social flex space-x-4 sm:space-x-3  md:space-x-4 lg:space-x-4 items-center h-full  ">
                    <?php $__currentLoopData = getSocialIcons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iconName=>$iconArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-10 mb:mb-0">
                            <a target="_blank" title="<?php echo e($iconName); ?>" href="<?php echo e($iconArr['link']); ?>"
                               class="w-8 h-8 flex items-center justify-center  bg-main object-cover rounded-full p-1 ">
                                <i class="<?php echo e($iconArr['icon']); ?> text-white icon-size"></i>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="footer__links w-full md:w-1/3 h-full flex flex-col mb-10 md:mb-0 ">
                <h3 class="normal__title capitalize md:mb-8"><?php echo e(__('Quick Links')); ?></h3>
                <ul class="columns-2 gap-2   justify-end">
                    <?php $__currentLoopData = footerPages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$footerPageArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class=" transition-all duration-400 hover:text-main text-black capitalize mb-5 inline-block font-normal"
                               href="<?php echo e($footerPageArr['link']); ?>"><?php echo e($footerPageArr['title']); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <a href="#"
                   class="font-semibold text-xs lg:text-base tracking-tight "><?php echo e(__('bookappointment@alfawzydental.com')); ?></a>
            </div>
            <div class="footer__addresses w-full md:w-1/3 ">
                <div class="branches flex flex-col h-full justify-between items-start md:items-center">

                    <div class="branch-parent mb-3">
                        <h2 class="font-semibold text-xl mb-3">
                            <?php echo e($settings->footer_title1); ?>


                        </h2>
                        <p class="font-normal text-black leading-7 max-w-[80%] md:max-w-[272px]"><?php echo e($settings->footer_desc1); ?></p>
                    </div>

                    <div class="branch-parent mb-3">
                        <h2 class="font-semibold text-xl mb-3">
                            <?php echo e($settings->footer_title2); ?>


                        </h2>
                        <p class="font-normal text-black leading-7 max-w-[80%] md:max-w-[272px]"><?php echo e($settings->footer_desc2); ?></p>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <div class="footer__bottom min-h-[60px]  flex items-center justify-center bg-main text-white">
        <?php echo e(__('Copyright © 2023 All Right Reserved Al Fawzy Dental.')); ?>

    </div>

</footer>

<script src="<?php echo e(asset('front/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('front/icons/fontawesome-6-4-2/js/all.min.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>



<script src="<?php echo e(url('front')); ?>/alertify/alertify.min.js"></script>


<?php echo $__env->yieldPushContent('js'); ?>


<script>
    window.addEventListener('online', () => {
        alertify.success('عادت خدمة الانترنت !');
    });
    window.addEventListener('offline', () => {
        alertify.error('لا يوجد خدمة انترنت !');
    });


    var swiper = new Swiper(".header-swiper", {
        spaceBetween: 30
        , slidesPerView: "1"
		,
		effect: 'fade',
		crossFade:true
        , centeredSlides: true
        , autoplay: {
            delay: 2500
            , disableOnInteraction: false
            ,
        }
        , pagination: {
            el: ".swiper-pagination-header"
            , clickable: true
            ,
        }
        , navigation: {
            nextEl: ".swiper-button-next-header"
            , prevEl: ".swiper-button-prev-header"
            ,
        }
        ,
    });

</script>
</body>
</html>
<?php /**PATH /home/thetailorsweb/public_html/alfawzydental.thetailorsweb.com/resources/views/front/layout/index.blade.php ENDPATH**/ ?>